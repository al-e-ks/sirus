DBM:RegisterMapSize("Ulduar",
	1, 3287.49987793, 2191.66662598,		-- The Grand Approach
	2, 669.45098877, 446.30004883,			-- The Antechamber of Ulduar
	3, 1328.460998535, 885.63989258,		-- The Inner Sanctum of Ulduar
	4, 910.5, 607,							-- The Prison of Yogg-Saron
	5, 1569.45996094, 1046.30004882,		-- The Spark of Imagination
	6, 619.46899414, 412.97998047			-- The Mind's Eye
)
