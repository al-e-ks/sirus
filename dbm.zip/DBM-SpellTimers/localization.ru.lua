DBM_SpellsUsed_Translations = {}

local L = DBM_SpellsUsed_Translations




L.TabCategory_SpellsUsed     = "КД заклинаний / умений"
L.AreaGeneral                = "Общие настройки для перезарядки заклинаний и умений"
L.Enable                     = "Включить таймеры восстановления"
L.Show_LocalMessage          = "Показывать локальное сообщение при касте"
L.Enable_inRaid              = "Показать перезарядки только у участников рейда"
L.Enable_inBattleground      = "Показать перезарядки также на полях сражений"
L.Enable_Portals             = "Показать продолжительность портала"
L.Reset                      = "Сброс к значениям по умолчанию"
L.Local_CastMessage          = "Обнаружено применение:% s"
L.AreaAuras                  = "Настройка заклинаний / навыков"
L.SpellID                    = "ID заклинания"
L.BarText                    = "Наименование (по умолчанию:от игрока в цель)"
L.Cooldown                   = "Восстановление"
L.Error_FillU                = "Пожалуйста, заполните все поля перед добавлением нового"




